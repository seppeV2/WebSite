import flet as ft
import os
from tabs.home import home_body, other_body
from tabs.information import information_body
def change_rail_menu_item(e, page):

    page.page_layout.update_appbar(
        page, 
        page.page_layout.navigationRail.navigation_rail.destinations[e.control.selected_index].label_content.value
    )

    if e.control.selected_index == 0:
        page.page_layout.set_body(page, home_body(page))
    elif e.control.selected_index == 1:
        page.page_layout.set_body(page, information_body(page))
    else: 
        page.page_layout.set_body(page, other_body(page))

    page.update()

class HoverNavigationRail(ft.Container):
    def __init__(self, page):
        super().__init__()
        self.expanded = True
        self.navigation_rail = ft.NavigationRail(
            destinations= [
                ft.NavigationRailDestination(label_content= ft.Text('Home', size=23, color=ft.Colors.GREY_800), 
                                             icon=ft.Icon(name = ft.Icons.HOME, size=50, color=ft.Colors.GREY_600), 
                                             selected_icon=ft.Icon(name = ft.Icons.HOME, size=60, color =ft.Colors.BLACK)),
                ft.NavigationRailDestination(label_content= ft.Text('Information', size=23, color=ft.Colors.GREY_800),
                                             icon=ft.Icon(name = ft.Icons.INFO, size=50, color=ft.Colors.GREY_600),
                                             selected_icon=ft.Icon(name = ft.Icons.INFO, size=60, color =ft.Colors.BLACK)),
                ft.NavigationRailDestination(label_content= ft.Text('Contacts', size=23, color=ft.Colors.GREY_800),
                                             icon=ft.Icon(name = ft.Icons.CONTACTS, size=50, color=ft.Colors.GREY_600), 
                                             selected_icon=ft.Icon(name = ft.Icons.CONTACTS, size=60, color =ft.Colors.BLACK)),
                ft.NavigationRailDestination(label_content= ft.Text('Help', size=23, color=ft.Colors.GREY_800),
                                             icon=ft.Icon(name = ft.Icons.HELP, size=50, color=ft.Colors.GREY_600), 
                                             selected_icon=ft.Icon(name = ft.Icons.HELP, size=60, color =ft.Colors.BLACK)),
                ft.NavigationRailDestination(label_content= ft.Text('Settings', size=23, color=ft.Colors.GREY_800),
                                             icon=ft.Icon(name = ft.Icons.SETTINGS, size=50, color=ft.Colors.GREY_600), 
                                             selected_icon=ft.Icon(name = ft.Icons.SETTINGS, size=60, color =ft.Colors.BLACK)),
                ft.NavigationRailDestination(label_content= ft.Text('Log Out', size=23, color=ft.Colors.GREY_800),
                                             icon=ft.Icon(name = ft.Icons.LOGIN, size=50, color=ft.Colors.GREY_600), 
                                             selected_icon=ft.Icon(name = ft.Icons.LOGIN, size=60, color =ft.Colors.BLACK)),
            ],
            height=page.height,
            selected_index=0,
            on_change= lambda e: change_rail_menu_item(e, page),
            label_type=ft.NavigationRailLabelType.NONE,
            indicator_color='#FFFFFF',
            indicator_shape=ft.ContinuousRectangleBorder(30),
        )

        self.on_hover = lambda e: self.extend_navigation_rail(page, e.data)

    def extend_navigation_rail(self, page, input):
        self.navigation_rail.extended = input
        page.update()

    def build(self):
        super().build()
        self.content = self.navigation_rail

class PageLayOut(ft.Container):
    def __init__(self, page, page_title, body=None):
        
        super().__init__()
        self.body = ft.Text()
        self.update_appbar(page, page_title)
        self.navigationRail = HoverNavigationRail(page)
        self.expand = True
        self.body = ft.Text('START CASE') if body == None else body
        self.content = self.build_content()

    def update_appbar(self, page, title):
        logoPath = 'PetillionLogo.png'
        self.appbar = ft.AppBar(
            title=ft.Text(title, text_align=ft.TextAlign.CENTER, size=40, weight=ft.FontWeight.W_600, color='#2C5C58'),
            leading=ft.Container(ft.Image(logoPath, fit=ft.ImageFit.FIT_WIDTH), margin=ft.margin.only(left = 10, top = 15)),
            leading_width=275,
            toolbar_height= 100,
            bgcolor=ft.Colors.GREY_300,
            center_title=True
        )
        page.appbar = self.appbar
        page.update()

    def build_content(self):
        self.content = ft.Row(
            controls=[
                self.navigationRail,
                ft.VerticalDivider(color='#2C5C58'),
                self.body,
            ]
        )

    def set_body(self, page, body):
        self.body = body
        self.build_content()
        page.update()


    def build(self):
        super().build()
        self.build_content()

def main(page: ft.Page):
    page.theme_mode = ft.ThemeMode.LIGHT

    page.page_layout = PageLayOut(page, 'Home', home_body(page))
    page.add(page.page_layout)




ft.app(main)

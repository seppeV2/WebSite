import flet as ft

def home_body(page):
    return ft.Container(
        content=ft.Column(
            controls = [
                ft.Text(
                    value='This is the Home page'
                ),
                ft.Icon(name = ft.Icons.HOME, size=60, color=ft.Colors.BLACK)
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10, 
        ),
        alignment=ft.alignment.center
    )

import flet as ft

def other_body(page):
    return ft.Container(
        content=ft.Column(
            controls = [
                ft.Text(
                    value='Still under construction'
                ),
                ft.Icon(name = ft.Icons.CONSTRUCTION, size=60, color=ft.Colors.BLACK)
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10, 
        ),
        alignment=ft.alignment.center
    )
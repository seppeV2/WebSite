import flet as ft

def information_body(page):
    return ft.Container(
        content=ft.Column(
            controls = [
                ft.Text(
                    value='This is the Information page'
                ),
                ft.Icon(name = ft.Icons.INFO, size=60, color=ft.Colors.BLACK)
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10, 
        ),
        alignment=ft.alignment.center
    )